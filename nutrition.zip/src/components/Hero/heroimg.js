import React from 'react';
import Classes from './hero.module.css'

const heroimg = (props) => {
    return (
        <div className={Classes.hero_image}>
            {/* <div className="hero-text">
                <h1>hello</h1>
            </div> */}
        </div>
    )
}

export default heroimg