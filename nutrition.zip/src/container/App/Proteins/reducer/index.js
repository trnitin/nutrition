import initialState from '../../../../Store/initialState';
import * as constant from '../constants/constants';
import * as Type from '../actions/actions';


const reducer = (state = initialState, action) => {
    console.log(Type, "fdsdf")
    switch (action.type) {
        case constant.LOAD_PROTEIN_DATA:
            return {
                ...state,
                protein: action.payload
            };
        // case constant.SELECT_PRODUCT:
        //     return {
        //         ...state,
        //         selectedProduct: action.payload
        //     }
        default: return {
            ...state
        }
    }

}

export default reducer;