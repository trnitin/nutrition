const initialState = {
    name: 'nitin',
    loggedIn: false,
    protein: [],
    fatburner: [],
    selectedProduct: []
}



export default initialState;