import firstSaga from './saga';
import { put, takeEvery, all } from 'redux-saga/effects'

function* secondhelloSaga() {
    console.log('Hello Sagas second time!')
}

export default function* rootSaga() {
    yield all([
        firstSaga(),
        secondhelloSaga(),
    ])
}
